import type { GridHero, SaveData } from '../types';

const SAVE_KEY = 'keykeep_hybrid_save_v5';
const defaultSaveData: SaveData = {
  unlockedLevel: 1, sovereignDucats: 900, antimatter: 15,
  equippedDeckIds: ['archer', 'knight', 'horseman', 'mage', 'trebuchet'],
  unlockedHeroIds: ['archer', 'knight', 'horseman', 'mage', 'trebuchet'],
  heroLevels: { archer: 1, knight: 1, horseman: 1, mage: 1, trebuchet: 1 }
};

export function loadSaveData(): SaveData {
  const raw = localStorage.getItem(SAVE_KEY);
  if (!raw) return structuredClone(defaultSaveData);
  try {
    const parsed: Partial<SaveData> = JSON.parse(raw) as Partial<SaveData>;
    return {
      ...defaultSaveData, ...parsed,
      sovereignDucats: Math.max(0, Number(parsed.sovereignDucats) || 0),
      antimatter: Math.max(0, Number(parsed.antimatter) || 0),
      equippedDeckIds: Array.isArray(parsed.equippedDeckIds) && parsed.equippedDeckIds.length === 5 ? parsed.equippedDeckIds : defaultSaveData.equippedDeckIds,
      unlockedHeroIds: Array.isArray(parsed.unlockedHeroIds) ? parsed.unlockedHeroIds : defaultSaveData.unlockedHeroIds,
      heroLevels: parsed.heroLevels && typeof parsed.heroLevels === 'object' ? parsed.heroLevels : defaultSaveData.heroLevels
    };
  } catch (error) {
    console.warn('[KeyKeep] Could not read save data; using defaults.', error);
    return structuredClone(defaultSaveData);
  }
}
export function writeSaveData(data: SaveData): void {
  localStorage.setItem(SAVE_KEY, JSON.stringify(data));
}

let saveData = loadSaveData();
let mana = 160;
let castleHp = 100;
const grid: (GridHero | null)[] = new Array(15).fill(null);
export const getSaveData = (): SaveData => saveData;
export const updateSaveData = (update: (data: SaveData) => SaveData): SaveData => {
  saveData = update(saveData); writeSaveData(saveData); return saveData;
};
export const getMana = (): number => mana;
export const setMana = (value: number): void => { mana = Math.max(0, value); };
export const getCastleHp = (): number => castleHp;
export const setCastleHp = (value: number): void => { castleHp = Math.max(0, value); };
export const getGrid = (): (GridHero | null)[] => grid;

import { Application, Container, Graphics, Sprite, Text, TextStyle, Texture } from 'pixi.js';
import { GameTextures, loadAllGameAssets } from '../gameAssets';
import { sound } from '../audio';
import { createPanel, createUiButton } from '../ui/uiHelpers';
import { ALL_HEROES, HERO_SIZE, KEY_LABELS, KEY_MAP, TARGET_MODES, TOTAL_CAMPAIGN_LEVELS, UPGRADE_COSTS, VIRTUAL_HEIGHT, VIRTUAL_WIDTH, WAYPOINTS } from '../constants';
import type { Enemy, EnemyId, GridHero, HeroDef, MenuTab } from '../types';

document.body.style.margin = '0';
document.body.style.padding = '0';
document.body.style.overflow = 'hidden';
document.body.style.backgroundColor = '#070b14';

let currentTargetModeIndex = 0;
let gameState: import('../types').GameState = 'MENU';
let currentMenuTab: import('../types').MenuTab = 'HOME';
interface SaveData {
  unlockedLevel: number;
  sovereignDucats: number;
  antimatter: number;
  equippedDeckIds: import('../types').HeroId[];
  unlockedHeroIds: import('../types').HeroId[];
  heroLevels: Record<string, number>;
}
function loadSaveData(): SaveData {
  const defaultData: SaveData = {
    unlockedLevel: 1, sovereignDucats: 900, antimatter: 15,
    equippedDeckIds: ['archer', 'knight', 'horseman', 'mage', 'trebuchet'],
    unlockedHeroIds: ['archer', 'knight', 'horseman', 'mage', 'trebuchet'],
    heroLevels: { archer: 1, knight: 1, horseman: 1, mage: 1, trebuchet: 1 }
  };
  const raw = localStorage.getItem('keykeep_hybrid_save_v5');
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      return {
        ...defaultData, ...parsed,
        sovereignDucats: Math.max(0, Number(parsed.sovereignDucats) || 0),
        antimatter: Math.max(0, Number(parsed.antimatter) || 0),
        equippedDeckIds: Array.isArray(parsed.equippedDeckIds) && parsed.equippedDeckIds.length === 5 ? parsed.equippedDeckIds : defaultData.equippedDeckIds,
        unlockedHeroIds: Array.isArray(parsed.unlockedHeroIds) ? parsed.unlockedHeroIds : defaultData.unlockedHeroIds,
        heroLevels: typeof parsed.heroLevels === 'object' && parsed.heroLevels ? parsed.heroLevels : defaultData.heroLevels
      };
    } catch (error) {
      console.warn('[KeyKeep] Failed to parse save data.', error);
    }
  }
  return defaultData;
}
function writeSaveData(data: SaveData): void {
  localStorage.setItem('keykeep_hybrid_save_v5', JSON.stringify(data));
}
let saveData = loadSaveData();
let currentCampaignLevel = 1;
let mana = 160;
let summonCost = 40;
let castleHp = 100;
let isGameOver = false;
let isVictory = false;
let currentWave = 1;
let maxWavesForLevel = 4;
let waveEnemiesSpawned = 0;
let waveEnemiesTotal = 10;
let waveSpawnInterval = 1.5;
let spawnTimer = 0;
let bossSpawnedThisWave = false;
let waveIntermissionTimer = 0;
const grid: (GridHero | null)[] = new Array(15).fill(null);
let enemies: Enemy[] = [];
let projectiles: import('../types').Projectile[] = [];
let hazards: import('../types').LaneHazard[] = [];
let floatingTexts: import('../types').FloatingText[] = [];
let particles: import('../types').Particle[] = [];
let nextEnemyId = 1;
let screenShakeTimer = 0;
let screenShakeMagnitude = 0;
function triggerScreenShake(magnitude = 4, duration = 0.15): void {
  screenShakeMagnitude = magnitude;
  screenShakeTimer = duration;
}
function spawnImpactParticles(container: Container, x: number, y: number, color: number, count = 6): void {
  for (let i = 0; i < count; i++) {
    const gfx = new Graphics();
    const size = 2 + Math.random() * 2.5;
    gfx.circle(0, 0, size).fill(color);
    gfx.position.set(x, y);
    container.addChild(gfx);
    const angle = Math.random() * Math.PI * 2;
    const speed = 40 + Math.random() * 90;
    particles.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
      life: 0.25 + Math.random() * 0.15, maxLife: 0.4, color, size, gfx });
  }
}

export async function run() {
  const app = new Application();
  
  await app.init({
    resizeTo: window,
    backgroundColor: 0x070b14,
    resolution: window.devicePixelRatio || 1,
    autoDensity: true,
    antialias: true
  });

  const appContainer = document.getElementById('app') || document.body;
  appContainer.appendChild(app.canvas);

  await loadAllGameAssets();

  const battleRoot = new Container();
  const menuRoot = new Container();
  app.stage.addChild(battleRoot, menuRoot);

  function screenToStage(clientX: number, clientY: number): { x: number; y: number } {
    const rect = app.canvas.getBoundingClientRect();
    const rawX = clientX - rect.left;
    const rawY = clientY - rect.top;
    return {
      x: (rawX - app.stage.position.x) / app.stage.scale.x,
      y: (rawY - app.stage.position.y) / app.stage.scale.y
    };
  }

  function resizeGameView() {
    const winW = window.innerWidth || VIRTUAL_WIDTH;
    const winH = window.innerHeight || VIRTUAL_HEIGHT;
    const scale = Math.max(0.1, Math.min(winW / VIRTUAL_WIDTH, winH / VIRTUAL_HEIGHT));

    app.stage.scale.set(scale);
    app.stage.position.set(
      (winW - VIRTUAL_WIDTH * scale) / 2,
      (winH - VIRTUAL_HEIGHT * scale) / 2
    );
  }
  window.addEventListener('resize', resizeGameView);
  resizeGameView();

  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  }

  function getEquippedHeroDeck(): HeroDef[] {
    return saveData.equippedDeckIds.map(id => {
      const def = ALL_HEROES.find(h => h.id === id);
      return def ? { ...def, level: saveData.heroLevels[id] || 1 } : ALL_HEROES[0];
    });
  }

  // Layers
  const backgroundLayer = new Container();
  const trackLayer = new Container();
  const hazardLayer = new Container();
  const enemyLayer = new Container();
  const battlementLayer = new Container();
  const gridLayer = new Container();
  const projectileLayer = new Container();
  const floatLayer = new Container();
  const uiLayer = new Container();
  const modalLayer = new Container();

  battleRoot.addChild(
    backgroundLayer, trackLayer, hazardLayer, enemyLayer,
    battlementLayer, gridLayer, projectileLayer, floatLayer,
    uiLayer, modalLayer
  );

  let targetBtn: Container | null = null;

  function cycleTargetMode() {
    currentTargetModeIndex = (currentTargetModeIndex + 1) % TARGET_MODES.length;
    if (targetBtn && targetBtn.children[1]) {
      (targetBtn.children[1] as Text).text = `Priority: ${TARGET_MODES[currentTargetModeIndex]} [Tab]`;
    }
  }

  // --- WAR ROOM MENU ---
  function renderStartMenu() {
    menuRoot.removeChildren();

    const tableBg = new Graphics();
    tableBg.rect(0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);
    tableBg.fill(0x1a0f0a);
    menuRoot.addChild(tableBg);

    const parchment = createPanel(GameTextures.panelBeige, 36, 76, 888, 480, 24);
    menuRoot.addChild(parchment);

    const headerPanel = createPanel(GameTextures.panelBrown, 16, 12, 928, 56, 16);
    menuRoot.addChild(headerPanel);

    const ducatText = new Text({
      text: `🧙 ${saveData.sovereignDucats} Ducats`,
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#fef08a', fontSize: 16 })
    });
    ducatText.position.set(40, 28);
    menuRoot.addChild(ducatText);

    const amCount = Math.max(0, saveData.antimatter);
    const amText = new Text({
      text: `🌀 ${amCount} Antimatter`,
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#e9d5ff', fontSize: 16 })
    });
    amText.position.set(240, 28);
    menuRoot.addChild(amText);

    const fsBtn = createUiButton(
      GameTextures.btnBeige,
      GameTextures.btnBeigePressed,
      135, 40,
      'â›¶ Fullscreen',
      new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 13 }),
      () => toggleFullscreen()
    );
    fsBtn.position.set(790, 20);
    menuRoot.addChild(fsBtn);

    const tabContainer = new Container();
    tabContainer.position.set(0, 80);
    menuRoot.addChild(tabContainer);

    if (currentMenuTab === 'HOME') renderWarRoomHomeTab(tabContainer);
    else if (currentMenuTab === 'CARDS') renderGarrisonCardsTab(tabContainer);
    else if (currentMenuTab === 'PORTALS') renderAntimatterPortalsTab(tabContainer);

    const bottomNav = new Graphics();
    bottomNav.rect(0, 565, VIRTUAL_WIDTH, 75);
    bottomNav.fill(0x0e0906);
    bottomNav.stroke({ width: 2, color: 0x6e3c0f });
    menuRoot.addChild(bottomNav);

    const tabs: { id: MenuTab; title: string; crest: string }[] = [
      { id: 'HOME', title: 'War Room', crest: '⚔' },
      { id: 'CARDS', title: 'Cards & Deck', crest: '🛡' },
      { id: 'PORTALS', title: 'Antimatter Portals', crest: '🌀' }
    ];

    tabs.forEach((tab, idx) => {
      const bx = 160 + idx * 240;
      const isActive = currentMenuTab === tab.id;

      const btn = createUiButton(
        isActive ? GameTextures.btnBrown : GameTextures.btnBeige,
        isActive ? GameTextures.btnBrownPressed : GameTextures.btnBeigePressed,
        200, 54,
        `${tab.crest} ${tab.title}`,
        new TextStyle({
          fontFamily: 'Cinzel Decorative',
          fill: isActive ? '#fef08a' : '#451a03',
          fontSize: 13,
          fontWeight: 'bold'
        }),
        () => {
          currentMenuTab = tab.id;
          renderStartMenu();
        }
      );
      btn.position.set(bx, 570);
      menuRoot.addChild(btn);
    });
  }

  // --- TAB 1: WAR ROOM ---
  function renderWarRoomHomeTab(parent: Container) {
    const title = new Text({
      text: `CAMPAIGN STAGE ${currentCampaignLevel}`,
      style: new TextStyle({ fontFamily: 'Cinzel Decorative', fill: '#451a03', fontSize: 24, fontWeight: 'bold' })
    });
    title.anchor.set(0.5);
    title.position.set(480, 24);
    parent.addChild(title);

    const deckLabel = new Text({
      text: 'ACTIVE 5-HERO WAR FORMATION (Click Hero to Inspect / Change)',
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 13 })
    });
    deckLabel.anchor.set(0.5);
    deckLabel.position.set(480, 56);
    parent.addChild(deckLabel);

    const activeDeck = getEquippedHeroDeck();
    const cStartX = 145;
    const cY = 75;
    const cW = 120;
    const cH = 160;
    const gap = 16;

    activeDeck.forEach((hero, idx) => {
      const card = new Container();
      card.position.set(cStartX + idx * (cW + gap), cY);

      const cardFrame = createPanel(GameTextures.panelInsetBrown, 0, 0, cW, cH, 14);
      card.addChild(cardFrame);

      const slotBadge = new Text({
        text: `SLOT ${idx + 1}`,
        style: new TextStyle({ fontFamily: 'Lilita One', fill: '#facc15', fontSize: 10 })
      });
      slotBadge.position.set(8, 6);
      card.addChild(slotBadge);

      const unitSprite = new Sprite(GameTextures[hero.textureKey] || Texture.WHITE);
      unitSprite.anchor.set(0.5);
      unitSprite.position.set(cW / 2, 58);
      unitSprite.width = 68;
      unitSprite.height = 68;
      card.addChild(unitSprite);

      const name = new Text({
        text: hero.name,
        style: new TextStyle({ fontFamily: 'Lilita One', fill: '#fef08a', fontSize: 14 })
      });
      name.anchor.set(0.5);
      name.position.set(cW / 2, 108);
      card.addChild(name);

      const lvl = new Text({
        text: `Lvl ${hero.level}`,
        style: new TextStyle({ fontFamily: 'Lilita One', fill: '#38bdf8', fontSize: 12 })
      });
      lvl.anchor.set(0.5);
      lvl.position.set(cW / 2, 132);
      card.addChild(lvl);

      card.eventMode = 'static';
      card.cursor = 'pointer';
      card.on('pointerdown', () => {
        sound.playKeypress();
        openHeroProfileModal(hero);
      });

      parent.addChild(card);
    });

    const marchBtn = createUiButton(
      GameTextures.btnBlue,
      GameTextures.btnBluePressed,
      320, 72,
      '⚔ï¸ MARCH TO WAR',
      new TextStyle({ fontFamily: 'Cinzel Decorative', fill: '#ffffff', fontSize: 18, fontWeight: 'bold' }),
      () => {
        sound.playWarHorn();
        setTimeout(startMatch, 150);
      }
    );
    marchBtn.position.set(320, 276);
    parent.addChild(marchBtn);

    const guideFrame = createPanel(GameTextures.panelInsetBeige, 180, 365, 600, 95, 14);
    parent.addChild(guideFrame);

    const guideText = new Text({
      text: 'WARROOM TACTICS & COMMANDS:\n• Press [Space] in battle to summon heroes using Soul Aether.\n• Strike [E, R, T, Y, U, D, F, G, H, J, C, V, B, N, M] to attack.\n• Drag matching heroes of the same tier together to merge.\n• Every completed wave awards +1 Antimatter for Portals!',
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#451a03', fontSize: 13, lineHeight: 18 })
    });
    guideText.position.set(200, 375);
    parent.addChild(guideText);
  }

  // --- TAB 2: GARRISON (CARDS & DECK BUILDER) ---
  function renderGarrisonCardsTab(parent: Container) {
    const title = new Text({
      text: 'ROYAL GARRISON & DECK BUILDER',
      style: new TextStyle({ fontFamily: 'Cinzel Decorative', fill: '#451a03', fontSize: 20, fontWeight: 'bold' })
    });
    title.anchor.set(0.5);
    title.position.set(480, 18);
    parent.addChild(title);

    const cW = 96;
    const cH = 142;
    const startX = 64;
    const gap = 12;

    ALL_HEROES.forEach((hero, idx) => {
      const isEquipped = saveData.equippedDeckIds.includes(hero.id);
      const isUnlocked = saveData.unlockedHeroIds.includes(hero.id);
      const level = saveData.heroLevels[hero.id] || 1;

      const col = idx % 8;
      const row = Math.floor(idx / 8);

      const card = new Container();
      card.position.set(startX + col * (cW + gap), 44 + row * (cH + gap));

      const frame = createPanel(isEquipped ? GameTextures.panelBrown : GameTextures.panelInsetBrown, 0, 0, cW, cH, 12);
      card.addChild(frame);

      if (isEquipped) {
        const slotIdx = saveData.equippedDeckIds.indexOf(hero.id) + 1;
        const badgeContainer = new Container();
        const badgeBg = new Graphics();
        badgeBg.roundRect(0, 0, 52, 16, 4);
        badgeBg.fill(0xfacc15);
        badgeContainer.addChild(badgeBg);

        const bText = new Text({
          text: `DECK #${slotIdx}`,
          style: new TextStyle({ fontFamily: 'Lilita One', fill: '#000000', fontSize: 9 })
        });
        bText.anchor.set(0.5);
        bText.position.set(26, 8);
        badgeContainer.addChild(bText);

        badgeContainer.position.set(4, 4);
        card.addChild(badgeContainer);
      }

      const sprite = new Sprite(GameTextures[hero.textureKey] || Texture.WHITE);
      sprite.anchor.set(0.5);
      sprite.position.set(cW / 2, 54);
      sprite.width = 58;
      sprite.height = 58;
      if (!isUnlocked) sprite.tint = 0x475569;
      card.addChild(sprite);

      const name = new Text({
        text: hero.name,
        style: new TextStyle({ fontFamily: 'Lilita One', fill: isUnlocked ? '#fef08a' : '#78716c', fontSize: 11 })
      });
      name.anchor.set(0.5);
      name.position.set(cW / 2, 96);
      card.addChild(name);

      const status = new Text({
        text: isUnlocked ? `Lvl ${level}` : 'LOCKED',
        style: new TextStyle({ fontFamily: 'Lilita One', fill: isUnlocked ? '#38bdf8' : '#ef4444', fontSize: 10 })
      });
      status.anchor.set(0.5);
      status.position.set(cW / 2, 118);
      card.addChild(status);

      card.eventMode = 'static';
      card.cursor = 'pointer';
      card.on('pointerdown', () => {
        sound.playKeypress();
        openHeroProfileModal(hero);
      });

      parent.addChild(card);
    });

    const info = new Text({
      text: 'Click any unlocked hero above to inspect stats, level up, or assign them to your 5-Hero Deck!',
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 13 })
    });
    info.anchor.set(0.5);
    info.position.set(480, 442);
    parent.addChild(info);
  }

  // --- DECK SWAP SLOT SELECTOR MODAL ---
  function openDeckSlotSelectorModal(newHero: HeroDef) {
    modalLayer.removeChildren();

    const overlay = new Graphics();
    overlay.rect(0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);
    overlay.fill({ color: 0x000000, alpha: 0.88 });
    modalLayer.addChild(overlay);

    const frame = createPanel(GameTextures.panelBeige, 160, 100, 640, 440, 20);
    modalLayer.addChild(frame);

    const title = new Text({
      text: `ASSIGN ${newHero.name.toUpperCase()} TO DECK`,
      style: new TextStyle({ fontFamily: 'Cinzel Decorative', fill: '#451a03', fontSize: 18, fontWeight: 'bold' })
    });
    title.anchor.set(0.5);
    title.position.set(480, 136);
    modalLayer.addChild(title);

    const sub = new Text({
      text: 'Choose which active slot to replace:',
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 14 })
    });
    sub.anchor.set(0.5);
    sub.position.set(480, 165);
    modalLayer.addChild(sub);

    const currentDeck = getEquippedHeroDeck();
    const slotW = 100;
    const slotH = 145;
    const startX = 180;
    const gap = 18;

    currentDeck.forEach((curHero, sIdx) => {
      const slotBox = new Container();
      slotBox.position.set(startX + sIdx * (slotW + gap), 195);

      const boxBg = createPanel(GameTextures.panelInsetBrown, 0, 0, slotW, slotH, 12);
      slotBox.addChild(boxBg);

      const sLabel = new Text({
        text: `SLOT ${sIdx + 1}`,
        style: new TextStyle({ fontFamily: 'Lilita One', fill: '#facc15', fontSize: 11 })
      });
      sLabel.anchor.set(0.5);
      sLabel.position.set(slotW / 2, 16);
      slotBox.addChild(sLabel);

      const sIcon = new Sprite(GameTextures[curHero.textureKey] || Texture.WHITE);
      sIcon.anchor.set(0.5);
      sIcon.position.set(slotW / 2, 58);
      sIcon.width = 54;
      sIcon.height = 54;
      slotBox.addChild(sIcon);

      const sName = new Text({
        text: curHero.name,
        style: new TextStyle({ fontFamily: 'Lilita One', fill: '#ffffff', fontSize: 12 })
      });
      sName.anchor.set(0.5);
      sName.position.set(slotW / 2, 96);
      slotBox.addChild(sName);

      const repBtn = createUiButton(
        GameTextures.btnBlue,
        GameTextures.btnBluePressed,
        slotW - 12, 28,
        'REPLACE',
        new TextStyle({ fontFamily: 'Lilita One', fill: '#ffffff', fontSize: 11 }),
        () => {
          saveData.equippedDeckIds[sIdx] = newHero.id;
          writeSaveData(saveData);
          sound.playUpgrade();
          modalLayer.removeChildren();
          renderStartMenu();
        }
      );
      repBtn.position.set(6, 110);
      slotBox.addChild(repBtn);

      modalLayer.addChild(slotBox);
    });

    const cancelBtn = createUiButton(
      GameTextures.btnBeige,
      GameTextures.btnBeigePressed,
      140, 42,
      'CANCEL',
      new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 13 }),
      () => {
        modalLayer.removeChildren();
        openHeroProfileModal(newHero);
      }
    );
    cancelBtn.position.set(410, 475);
    modalLayer.addChild(cancelBtn);
  }

  // --- DETAILED HERO PROFILE MODAL ---
  function openHeroProfileModal(heroDef: HeroDef) {
    modalLayer.removeChildren();

    const isUnlocked = saveData.unlockedHeroIds.includes(heroDef.id);
    const isEquipped = saveData.equippedDeckIds.includes(heroDef.id);
    const level = saveData.heroLevels[heroDef.id] || 1;
    const dmg = heroDef.baseDamage * level;
    const hp = heroDef.vitalityHp * level;
    const def = heroDef.armorDefense * level;

    const overlay = new Graphics();
    overlay.rect(0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);
    overlay.fill({ color: 0x000000, alpha: 0.85 });
    modalLayer.addChild(overlay);

    const scroll = createPanel(GameTextures.panelBeige, 240, 60, 480, 500, 24);
    modalLayer.addChild(scroll);

    const sprite = new Sprite(GameTextures[heroDef.textureKey] || Texture.WHITE);
    sprite.anchor.set(0.5);
    sprite.position.set(480, 140);
    sprite.width = 110;
    sprite.height = 110;
    if (!isUnlocked) sprite.tint = 0x57534e;
    modalLayer.addChild(sprite);

    const name = new Text({
      text: heroDef.name.toUpperCase(),
      style: new TextStyle({ fontFamily: 'Cinzel Decorative', fill: '#451a03', fontSize: 24, fontWeight: 'bold' })
    });
    name.anchor.set(0.5);
    name.position.set(480, 210);
    modalLayer.addChild(name);

    const title = new Text({
      text: `${heroDef.title} • Level ${level}`,
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#854d0e', fontSize: 14 })
    });
    title.anchor.set(0.5);
    title.position.set(480, 236);
    modalLayer.addChild(title);

    const statInset = createPanel(GameTextures.panelInsetBeige, 270, 260, 420, 115, 14);
    modalLayer.addChild(statInset);

    const statsText = new Text({
      text: `⚔ï¸ ATTACK DAMAGE: ${dmg} pts (Scales with merge tier)\n❤️ VITALITY (HP): ${hp} pts (Fortifies keep resistance)\n🛡ï¸ ARMOR DEFENSE: ${def} rating (Reduces monster penetration)\n⚡ VELOCITY: ${heroDef.projSpeed} px/s  |  RADIUS: ${heroDef.projRadius}`,
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#271206', fontSize: 13, lineHeight: 20 })
    });
    statsText.position.set(285, 272);
    modalLayer.addChild(statsText);

    const abilityText = new Text({
      text: `EMPOWERED ABILITY: ${heroDef.abilityName}\n${heroDef.description}`,
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 13, wordWrap: true, wordWrapWidth: 400 })
    });
    abilityText.position.set(280, 390);
    modalLayer.addChild(abilityText);

    if (isUnlocked) {
      const equipBtn = createUiButton(
        isEquipped ? GameTextures.btnBrown : GameTextures.btnBlue,
        isEquipped ? GameTextures.btnBrownPressed : GameTextures.btnBluePressed,
        190, 44,
        isEquipped ? 'IN ACTIVE DECK' : 'CHANGE DECK SLOT',
        new TextStyle({ fontFamily: 'Lilita One', fill: '#ffffff', fontSize: 12 }),
        () => {
          if (!isEquipped) {
            openDeckSlotSelectorModal(heroDef);
          }
        }
      );
      equipBtn.position.set(270, 470);
      modalLayer.addChild(equipBtn);

      const upCost = UPGRADE_COSTS[level] || 1200;
      const canUpgrade = saveData.sovereignDucats >= upCost && level < 4;

      const upBtn = createUiButton(
        GameTextures.btnBeige,
        GameTextures.btnBeigePressed,
        200, 44,
        level >= 4 ? 'MAX LEVEL' : `UPGRADE (${upCost} 🧙)`,
        new TextStyle({ fontFamily: 'Lilita One', fill: canUpgrade ? '#16a34a' : '#78716c', fontSize: 12 }),
        () => {
          if (canUpgrade) {
            saveData.sovereignDucats -= upCost;
            saveData.heroLevels[heroDef.id] = (saveData.heroLevels[heroDef.id] || 1) + 1;
            sound.playUpgrade();
            writeSaveData(saveData);
            openHeroProfileModal(heroDef);
          }
        }
      );
      upBtn.position.set(490, 470);
      modalLayer.addChild(upBtn);
    } else {
      const lockNotice = new Text({
        text: 'LOCKED HERO: SUMMON FROM ANTIMATTER PORTALS TAB TO UNLOCK',
        style: new TextStyle({ fontFamily: 'Lilita One', fill: '#991b1b', fontSize: 12 })
      });
      lockNotice.anchor.set(0.5);
      lockNotice.position.set(480, 485);
      modalLayer.addChild(lockNotice);
    }

    const closeBtn = new Container();
    closeBtn.eventMode = 'static';
    closeBtn.cursor = 'pointer';

    const closeCircle = new Graphics();
    closeCircle.circle(0, 0, 16);
    closeCircle.fill(0x7f1d1d);
    closeCircle.stroke({ width: 2, color: 0xfacc15 });
    closeBtn.addChild(closeCircle);

    const closeTxt = new Text({
      text: '✕',
      style: new TextStyle({ fill: '#ffffff', fontSize: 16, fontWeight: 'bold' })
    });
    closeTxt.anchor.set(0.5);
    closeBtn.addChild(closeTxt);

    closeBtn.position.set(700, 80);
    closeBtn.on('pointerdown', () => {
      modalLayer.removeChildren();
      renderStartMenu();
    });
    modalLayer.addChild(closeBtn);
  }

  // --- TAB 3: ANTIMATTER PORTALS WITH ANIMATION SEQUENCE ---
  function renderAntimatterPortalsTab(parent: Container) {
    const title = new Text({
      text: 'ANTIMATTER SUMMONING SANCTUM',
      style: new TextStyle({ fontFamily: 'Cinzel Decorative', fill: '#451a03', fontSize: 20, fontWeight: 'bold' })
    });
    title.anchor.set(0.5);
    title.position.set(480, 20);
    parent.addChild(title);

    const subtitle = new Text({
      text: 'Each wave cleared in battle awards +1 Antimatter! Channel them to unlock all 10 heroes.',
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 12 })
    });
    subtitle.anchor.set(0.5);
    subtitle.position.set(480, 45);
    parent.addChild(subtitle);

    const portals = [
      { name: 'Astral Portal', cost: 5, color: 0x38bdf8, desc: 'Summons 1 Hero. Unlocks locked heroes or levels up roster.' },
      { name: 'Void Singularity', cost: 12, color: 0xc084fc, desc: 'Guaranteed locked Hero Unlock + 350 Sovereign Ducats!' }
    ];

    portals.forEach((p, idx) => {
      const box = new Container();
      box.position.set(160 + idx * 340, 75);

      const frame = createPanel(GameTextures.panelInsetBrown, 0, 0, 300, 340, 14);
      box.addChild(frame);

      const vortex = new Graphics();
      vortex.circle(150, 110, 56);
      vortex.fill({ color: p.color, alpha: 0.35 });
      vortex.stroke({ width: 3, color: 0xc084fc });
      vortex.circle(150, 110, 36);
      vortex.fill({ color: 0xffffff, alpha: 0.8 });
      vortex.circle(150, 110, 18);
      vortex.fill(p.color);
      box.addChild(vortex);

      const pTitle = new Text({
        text: p.name,
        style: new TextStyle({ fontFamily: 'Cinzel Decorative', fill: '#ffffff', fontSize: 16, fontWeight: 'bold' })
      });
      pTitle.anchor.set(0.5);
      pTitle.position.set(150, 195);
      box.addChild(pTitle);

      const pDesc = new Text({
        text: p.desc,
        style: new TextStyle({ fontFamily: 'Lilita One', fill: '#cbd5e1', fontSize: 12, align: 'center', wordWrap: true, wordWrapWidth: 260 })
      });
      pDesc.anchor.set(0.5);
      pDesc.position.set(150, 235);
      box.addChild(pDesc);

      const canAfford = saveData.antimatter >= p.cost;

      const summonBtn = createUiButton(
        canAfford ? GameTextures.btnBlue : GameTextures.btnBrown,
        canAfford ? GameTextures.btnBluePressed : GameTextures.btnBrownPressed,
        240, 46,
        `CHANNEL (${p.cost} 🌀)`,
        new TextStyle({ fontFamily: 'Lilita One', fill: canAfford ? '#ffffff' : '#78716c', fontSize: 14 }),
        () => {
          if (saveData.antimatter < p.cost) {
            sound.playKeypress();
            spawnFloatingText('Need More Antimatter!', 480, 260, '#ef4444');
            return;
          }

          saveData.antimatter = Math.max(0, saveData.antimatter - p.cost);
          writeSaveData(saveData);
          sound.playMagicBlast();

          const locked = ALL_HEROES.filter(h => !saveData.unlockedHeroIds.includes(h.id));
          if (locked.length > 0) {
            const unlockedHero = locked[Math.floor(Math.random() * locked.length)];
            saveData.unlockedHeroIds.push(unlockedHero.id);
            saveData.heroLevels[unlockedHero.id] = 1;
            writeSaveData(saveData);
            triggerSummonAnimation(unlockedHero, true, 0);
          } else {
            const randomHero = ALL_HEROES[Math.floor(Math.random() * ALL_HEROES.length)];
            saveData.heroLevels[randomHero.id] = (saveData.heroLevels[randomHero.id] || 1) + 1;
            saveData.sovereignDucats += 350;
            writeSaveData(saveData);
            triggerSummonAnimation(randomHero, false, 350);
          }
        }
      );
      summonBtn.position.set(30, 275);
      box.addChild(summonBtn);

      parent.addChild(box);
    });
  }

  // --- ANIMATED PORTAL SUMMONING POPUP ---
  function triggerSummonAnimation(hero: HeroDef, isNew: boolean, bonusGold: number) {
    modalLayer.removeChildren();

    const overlay = new Graphics();
    overlay.rect(0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);
    overlay.fill({ color: 0x000000, alpha: 0.9 });
    modalLayer.addChild(overlay);

    const animContainer = new Container();
    animContainer.position.set(480, 320);
    modalLayer.addChild(animContainer);

    // Whirling Portal Rays
    const portalRays = new Graphics();
    for (let r = 0; r < 8; r++) {
      const ang = (r * Math.PI) / 4;
      portalRays.moveTo(0, 0);
      portalRays.lineTo(Math.cos(ang) * 160, Math.sin(ang) * 160);
    }
    portalRays.stroke({ width: 4, color: 0xc084fc, alpha: 0.7 });
    animContainer.addChild(portalRays);

    const cardContainer = new Container();
    cardContainer.scale.set(0.1);
    animContainer.addChild(cardContainer);

    const frame = createPanel(GameTextures.panelBeige, -180, -200, 360, 400, 20);
    cardContainer.addChild(frame);

    const bannerText = new Text({
      text: isNew ? '✨ NEW HERO UNLOCKED! ✨' : '⚡ HERO EMPOWERED! ⚡',
      style: new TextStyle({ fontFamily: 'Cinzel Decorative', fill: isNew ? '#16a34a' : '#0284c7', fontSize: 16, fontWeight: 'bold' })
    });
    bannerText.anchor.set(0.5);
    bannerText.position.set(0, -155);
    cardContainer.addChild(bannerText);

    const sprite = new Sprite(GameTextures[hero.textureKey] || Texture.WHITE);
    sprite.anchor.set(0.5);
    sprite.position.set(0, -60);
    sprite.width = 110;
    sprite.height = 110;
    cardContainer.addChild(sprite);

    const nameText = new Text({
      text: hero.name.toUpperCase(),
      style: new TextStyle({ fontFamily: 'Cinzel Decorative', fill: '#451a03', fontSize: 24, fontWeight: 'bold' })
    });
    nameText.anchor.set(0.5);
    nameText.position.set(0, 15);
    cardContainer.addChild(nameText);

    const descText = new Text({
      text: isNew 
        ? `${hero.title}\nAdded to your Royal Garrison!`
        : `Upgraded to Level ${saveData.heroLevels[hero.id]}!\n+${bonusGold} Sovereign Ducats secured!`,
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 13, align: 'center', lineHeight: 18 })
    });
    descText.anchor.set(0.5);
    descText.position.set(0, 65);
    cardContainer.addChild(descText);

    const claimBtn = createUiButton(
      GameTextures.btnBlue,
      GameTextures.btnBluePressed,
      200, 48,
      'COLLECT HERO',
      new TextStyle({ fontFamily: 'Lilita One', fill: '#ffffff', fontSize: 14 }),
      () => {
        sound.playUpgrade();
        app.ticker.remove(animTicker);
        modalLayer.removeChildren();
        renderStartMenu();
      }
    );
    claimBtn.position.set(-100, 130);
    cardContainer.addChild(claimBtn);

    let animProgress = 0;
    const animTicker = (ticker: any) => {
      portalRays.rotation += ticker.deltaTime * 0.05;
      if (animProgress < 1.0) {
        animProgress += ticker.deltaTime * 0.04;
        const scaleVal = Math.min(1.0, animProgress * 1.15);
        cardContainer.scale.set(scaleVal);
      }
    };
    app.ticker.add(animTicker);
  }

  function startMatch() {
    gameState = 'BATTLE';
    menuRoot.visible = false;
    battleRoot.visible = true;
    restartMatch();
  }

  function returnToMenu() {
    gameState = 'MENU';
    modalLayer.removeChildren();
    menuRoot.visible = true;
    battleRoot.visible = false;
    renderStartMenu();
  }

  // --- BATTLEFIELD ARENA ---
  const terrain = new Graphics();
  terrain.rect(0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);
  terrain.fill(0x355e3b);
  backgroundLayer.addChild(terrain);

  const roadBase = new Graphics();
  roadBase.moveTo(WAYPOINTS[0].x, WAYPOINTS[0].y);
  roadBase.lineTo(WAYPOINTS[1].x, WAYPOINTS[1].y);
  roadBase.lineTo(WAYPOINTS[2].x, WAYPOINTS[2].y);
  roadBase.lineTo(WAYPOINTS[3].x, WAYPOINTS[3].y);
  roadBase.stroke({ width: 68, color: 0x54433a, cap: 'round', join: 'round' });

  roadBase.moveTo(WAYPOINTS[0].x, WAYPOINTS[0].y);
  roadBase.lineTo(WAYPOINTS[1].x, WAYPOINTS[1].y);
  roadBase.lineTo(WAYPOINTS[2].x, WAYPOINTS[2].y);
  roadBase.lineTo(WAYPOINTS[3].x, WAYPOINTS[3].y);
  roadBase.stroke({ width: 56, color: 0xc8aa82, cap: 'round', join: 'round' });
  trackLayer.addChild(roadBase);

  const tree1 = new Sprite(GameTextures.treeProp);
  tree1.position.set(40, 240);
  tree1.width = 48; tree1.height = 48;
  backgroundLayer.addChild(tree1);

  const tree2 = new Sprite(GameTextures.treeProp);
  tree2.position.set(45, 330);
  tree2.width = 48; tree2.height = 48;
  backgroundLayer.addChild(tree2);

  const tree3 = new Sprite(GameTextures.treeProp);
  tree3.position.set(900, 240);
  tree3.width = 48; tree3.height = 48;
  backgroundLayer.addChild(tree3);

  const castleSprite = new Sprite(GameTextures.castleKeep);
  castleSprite.anchor.set(0.5);
  castleSprite.position.set(785, 480);
  castleSprite.width = 110;
  castleSprite.height = 110;
  trackLayer.addChild(castleSprite);

  const castleBarContainer = new Container();
  castleBarContainer.position.set(725, 545);
  uiLayer.addChild(castleBarContainer);

  const barBack = createPanel(GameTextures.panelInsetBrown, 0, 0, 120, 16, 6);
  castleBarContainer.addChild(barBack);

  const barFill = new Graphics();
  castleBarContainer.addChild(barFill);

  const castleHpText = new Text({
    text: `Keep: ${castleHp}/100`,
    style: new TextStyle({ fontFamily: 'Lilita One', fill: '#ffffff', fontSize: 11 })
  });
  castleHpText.anchor.set(0.5);
  castleHpText.position.set(60, 8);
  castleBarContainer.addChild(castleHpText);

  function updateCastleHpVisual() {
    const pct = Math.max(0, castleHp / 100);
    barFill.clear();
    barFill.roundRect(2, 2, 116 * pct, 12, 3);
    barFill.fill(pct > 0.4 ? 0x22c55e : 0xef4444);
    castleHpText.text = `Keep: ${castleHp}/100`;
  }
  updateCastleHpVisual();

  const cellW = 86;
  const cellH = 86;
  const gridW = cellW * 5;
  const gridH = cellH * 3;
  const wallPad = 12;

  const fX = 265;
  const fY = 156;

  const platform = new Graphics();
  platform.roundRect(fX - wallPad, fY - wallPad, gridW + wallPad * 2, gridH + wallPad * 2, 12);
  platform.fill(0x64748b);
  platform.stroke({ width: 3, color: 0x334155 });
  battlementLayer.addChild(platform);

  const tileContainers: Container[] = [];
  const tilePedestals: Graphics[] = [];
  const tileHeroWrappers: Container[] = [];
  const tileHeroSprites: Sprite[] = [];
  const tileChargeBars: Graphics[] = [];
  const tileRestTexts: Text[] = [];

  let draggedIndex: number | null = null;
  let dragGhost: Sprite | null = null;

  for (let i = 0; i < 15; i++) {
    const col = i % 5;
    const row = Math.floor(i / 5);
    const x = fX + col * cellW;
    const y = fY + row * cellH;

    const tile = new Container();
    tile.position.set(x, y);

    const isLightGreen = (col + row) % 2 === 0;
    const lawnColor = isLightGreen ? 0x82b54b : 0x6e9f3d;

    const bg = new Graphics();
    bg.rect(0, 0, cellW, cellH);
    bg.fill(lawnColor);
    bg.stroke({ width: 1, color: 0x4f772d, alpha: 0.4 });
    tile.addChild(bg);

    const keyBadge = new Graphics();
    keyBadge.roundRect(4, 4, 18, 18, 4);
    keyBadge.fill({ color: 0x18181b, alpha: 0.6 });
    tile.addChild(keyBadge);

    const keyTxt = new Text({
      text: KEY_LABELS[i],
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#fef08a', fontSize: 10 })
    });
    keyTxt.anchor.set(0.5);
    keyTxt.position.set(13, 13);
    tile.addChild(keyTxt);

    const pedestalGfx = new Graphics();
    tile.addChild(pedestalGfx);
    tilePedestals.push(pedestalGfx);

    const heroWrapper = new Container();
    heroWrapper.position.set(cellW / 2, cellH / 2);
    tile.addChild(heroWrapper);
    tileHeroWrappers.push(heroWrapper);

    const heroSprite = new Sprite();
    heroSprite.anchor.set(0.5);
    heroSprite.width = HERO_SIZE;
    heroSprite.height = HERO_SIZE;
    heroSprite.visible = false;
    heroWrapper.addChild(heroSprite);
    tileHeroSprites.push(heroSprite);

    const chargeBar = new Graphics();
    chargeBar.rect(8, cellH - 7, cellW - 16, 3);
    chargeBar.fill(0x0f172a);
    tile.addChild(chargeBar);
    tileChargeBars.push(chargeBar);

    const restText = new Text({
      text: '',
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#ef4444', fontSize: 11, align: 'center' })
    });
    restText.anchor.set(0.5);
    restText.position.set(cellW / 2, cellH / 2);
    tile.addChild(restText);
    tileRestTexts.push(restText);

    tile.eventMode = 'static';
    tile.cursor = 'pointer';

    tile.on('pointerdown', (e) => {
      if (grid[i] !== null && !grid[i]?.isOverheated && !isGameOver) {
        draggedIndex = i;
        const tex = GameTextures[grid[i]!.type.textureKey] || Texture.WHITE;
        dragGhost = new Sprite(tex);
        dragGhost.anchor.set(0.5);
        dragGhost.width = HERO_SIZE;
        dragGhost.height = HERO_SIZE;
        dragGhost.alpha = 0.85;

        const stagePos = screenToStage(e.global.x, e.global.y);
        dragGhost.position.set(stagePos.x, stagePos.y);
        gridLayer.addChild(dragGhost);
      }
    });

    tileContainers.push(tile);
    gridLayer.addChild(tile);
  }

  const studsGfx = new Graphics();
  for (let c = 1; c < 5; c++) {
    for (let r = 1; r < 3; r++) {
      const sx = fX + c * cellW;
      const sy = fY + r * cellH;
      studsGfx.circle(sx, sy, 4.5);
      studsGfx.fill(0xf8fafc);
      studsGfx.stroke({ width: 1.5, color: 0x475569 });
    }
  }
  gridLayer.addChild(studsGfx);

  function renderHeroPedestal(gfx: Graphics, hero: GridHero, cx: number, cy: number) {
    gfx.clear();
    const color = hero.type.pedestalColor;
    const tier = hero.tier;

    if (tier === 1) {
      gfx.circle(cx, cy, 32);
      gfx.fill({ color, alpha: 0.85 });
      gfx.stroke({ width: 2.5, color: 0xffffff });
    } else if (tier === 2) {
      gfx.moveTo(cx - 30, cy + 30);
      gfx.quadraticCurveTo(cx - 16, cy - 16, cx + 30, cy - 30);
      gfx.quadraticCurveTo(cx + 16, cy + 16, cx - 30, cy + 30);
      gfx.fill({ color, alpha: 0.9 });
      gfx.stroke({ width: 2.5, color: 0xffffff });
    } else if (tier === 3) {
      const p1 = { x: cx, y: cy - 32 };
      const p2 = { x: cx + 30, y: cy + 24 };
      const p3 = { x: cx - 30, y: cy + 24 };
      gfx.poly([p1.x, p1.y, p2.x, p2.y, p3.x, p3.y]);
      gfx.fill({ color, alpha: 0.9 });
      gfx.stroke({ width: 2.5, color: 0xffffff });
    } else {
      gfx.roundRect(cx - 28, cy - 28, 56, 56, 8);
      gfx.fill({ color, alpha: 0.9 });
      gfx.stroke({ width: 2.5, color: 0xfacc15 });
    }
  }

  window.addEventListener('pointermove', (e) => {
    if (dragGhost && draggedIndex !== null) {
      const { x, y } = screenToStage(e.clientX, e.clientY);
      dragGhost.position.set(x, y);
    }
  });

  window.addEventListener('pointerup', (e) => {
    if (dragGhost) {
      gridLayer.removeChild(dragGhost);
      dragGhost.destroy();
      dragGhost = null;
    }

    if (draggedIndex !== null) {
      const { x, y } = screenToStage(e.clientX, e.clientY);

      let targetIndex: number | null = null;
      for (let i = 0; i < 15; i++) {
        const tile = tileContainers[i];
        if (x >= tile.x && x <= tile.x + cellW && y >= tile.y && y <= tile.y + cellH) {
          targetIndex = i;
          break;
        }
      }

      if (
        targetIndex !== null &&
        targetIndex !== draggedIndex &&
        grid[targetIndex] &&
        grid[draggedIndex]
      ) {
        const src = grid[draggedIndex]!;
        const dest = grid[targetIndex]!;

        if (src.type.id === dest.type.id && src.tier === dest.tier) {
          dest.tier += 1;
          dest.attacksRemainingForAbility = 10;
          grid[draggedIndex] = null;
          sound.playUpgrade();
          spawnFloatingText(`TIER ${dest.tier}!`, tileContainers[targetIndex].x + cellW / 2, tileContainers[targetIndex].y + 15, '#facc15');
          updateTileVisual(draggedIndex);
          updateTileVisual(targetIndex);
        }
      }

      draggedIndex = null;
    }
  });

  function updateTileVisual(idx: number) {
    const hero = grid[idx];
    const pedestal = tilePedestals[idx];
    const sprite = tileHeroSprites[idx];
    const charge = tileChargeBars[idx];
    const restText = tileRestTexts[idx];

    pedestal.clear();
    charge.clear();

    if (!hero) {
      sprite.visible = false;
      restText.text = '';
      charge.rect(8, cellH - 7, cellW - 16, 3);
      charge.fill(0x0f172a);
    } else {
      sprite.texture = GameTextures[hero.type.textureKey] || Texture.WHITE;
      sprite.width = HERO_SIZE;
      sprite.height = HERO_SIZE;
      sprite.visible = true;

      // Always keep upright
      sprite.rotation = 0;

      if (hero.isOverheated) {
        sprite.alpha = 0.3;
        restText.text = `REST\n${hero.overheatCooldown.toFixed(1)}s`;
      } else {
        sprite.alpha = 1.0;
        restText.text = '';

        renderHeroPedestal(pedestal, hero, cellW / 2, cellH / 2);

        const progress = (10 - hero.attacksRemainingForAbility) / 10;
        charge.rect(8, cellH - 7, (cellW - 16) * progress, 3);
        charge.fill(0xfacc15);
      }
    }
  }

  function spawnFloatingText(msg: string, x: number, y: number, color = '#ffffff') {
    const txt = new Text({
      text: msg,
      style: new TextStyle({ fontFamily: 'Lilita One', fill: color, fontSize: 13 })
    });
    txt.anchor.set(0.5);
    txt.position.set(x, y);
    floatLayer.addChild(txt);

    floatingTexts.push({
      text: txt,
      x, y,
      vy: -35,
      life: 0.65,
      maxLife: 0.65
    });
  }

  // Unwarped Battle Top HUD Panel (9-slice)
  const hudPanel = createPanel(GameTextures.panelBrown, 16, 12, 540, 64, 16);
  uiLayer.addChild(hudPanel);

  const manaText = new Text({
    text: `Aether: ${mana}`,
    style: new TextStyle({ fontFamily: 'Lilita One', fill: '#38bdf8', fontSize: 16 })
  });
  manaText.position.set(30, 20);
  uiLayer.addChild(manaText);

  const goldBattleText = new Text({
    text: `Ducats: ${saveData.sovereignDucats}`,
    style: new TextStyle({ fontFamily: 'Lilita One', fill: '#facc15', fontSize: 15 })
  });
  goldBattleText.position.set(30, 46);
  uiLayer.addChild(goldBattleText);

  const levelWaveText = new Text({
    text: `Stage ${currentCampaignLevel} - Wave ${currentWave}/${maxWavesForLevel}`,
    style: new TextStyle({ fontFamily: 'Cinzel Decorative', fill: '#f8fafc', fontSize: 14, fontWeight: 'bold' })
  });
  levelWaveText.position.set(160, 20);
  uiLayer.addChild(levelWaveText);

  targetBtn = createUiButton(
    GameTextures.btnBeige,
    GameTextures.btnBeigePressed,
    190, 28,
    `Priority: ${TARGET_MODES[currentTargetModeIndex]} [Tab]`,
    new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 11 }),
    () => cycleTargetMode()
  );
  targetBtn.position.set(160, 44);
  uiLayer.addChild(targetBtn);

  const returnBtn = createUiButton(
    GameTextures.btnBeige,
    GameTextures.btnBeigePressed,
    85, 46,
    'MENU',
    new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 12 }),
    () => returnToMenu()
  );
  returnBtn.position.set(455, 20);
  uiLayer.addChild(returnBtn);

  const summonBtn = createUiButton(
    GameTextures.btnBlue,
    GameTextures.btnBluePressed,
    220, 46,
    `Summon (${summonCost}) [Space]`,
    new TextStyle({ fontFamily: 'Lilita One', fill: '#ffffff', fontSize: 13 }),
    () => summonHero()
  );
  summonBtn.position.set(370, 444);
  uiLayer.addChild(summonBtn);

  const upgradeCards: Container[] = [];
  const upgradeCostTexts: Text[] = [];
  const upgradeLvlTexts: Text[] = [];

  const trayStartX = 206;
  const trayY = 502;
  const cardW = 104;
  const cardH = 102;
  const cardGap = 8;

  function refreshBottomDeckTray() {
    upgradeCards.forEach(c => uiLayer.removeChild(c));
    upgradeCards.length = 0;
    upgradeCostTexts.length = 0;
    upgradeLvlTexts.length = 0;

    const equippedDeck = getEquippedHeroDeck();

    equippedDeck.forEach((heroDef, idx) => {
      const card = new Container();
      card.position.set(trayStartX + idx * (cardW + cardGap), trayY);

      const frame = createPanel(GameTextures.panelInsetBrown, 0, 0, cardW, cardH, 12);
      card.addChild(frame);

      const keyBadge = new Text({
        text: `[${idx + 1}]`,
        style: new TextStyle({ fontFamily: 'Lilita One', fill: '#facc15', fontSize: 11 })
      });
      keyBadge.position.set(6, 4);
      card.addChild(keyBadge);

      const charIcon = new Sprite(GameTextures[heroDef.textureKey] || Texture.WHITE);
      charIcon.anchor.set(0.5);
      charIcon.position.set(cardW / 2, 36);
      charIcon.width = 54;
      charIcon.height = 54;
      card.addChild(charIcon);

      const lvlText = new Text({
        text: `Lvl ${heroDef.level}`,
        style: new TextStyle({ fontFamily: 'Lilita One', fill: '#38bdf8', fontSize: 11 })
      });
      lvlText.anchor.set(0.5);
      lvlText.position.set(cardW / 2, 58);
      card.addChild(lvlText);
      upgradeLvlTexts.push(lvlText);

      const costBtn = createUiButton(
        GameTextures.btnBeige,
        GameTextures.btnBeigePressed,
        cardW - 16, 24,
        `▲ 100`,
        new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 11 }),
        () => upgradeHeroCard(idx)
      );
      costBtn.position.set(8, 72);
      card.addChild(costBtn);

      const costTxt = costBtn.children[1] as Text;
      if (costTxt) upgradeCostTexts.push(costTxt);

      upgradeCards.push(card);
      uiLayer.addChild(card);
    });
  }

  function upgradeHeroCard(deckIndex: number) {
    const equipped = getEquippedHeroDeck();
    const heroDef = equipped[deckIndex];
    if (!heroDef) return;

    const currentLvl = heroDef.level;
    if (currentLvl >= 4) return;

    const cost = UPGRADE_COSTS[currentLvl];
    if (mana >= cost) {
      mana -= cost;
      saveData.heroLevels[heroDef.id] = currentLvl + 1;
      writeSaveData(saveData);
      sound.playUpgrade();
      updateUpgradeCardsUI();

      spawnFloatingText(`UPGRADE!`, trayStartX + deckIndex * (cardW + cardGap) + cardW / 2, trayY, '#38bdf8');

      for (let g = 0; g < 15; g++) {
        if (grid[g]?.type.id === heroDef.id) {
          grid[g]!.type.level = currentLvl + 1;
          updateTileVisual(g);
        }
      }
    }
  }

  function updateUpgradeCardsUI() {
    const equipped = getEquippedHeroDeck();
    equipped.forEach((heroDef, idx) => {
      const lvl = heroDef.level;
      const lvlText = upgradeLvlTexts[idx];
      const costText = upgradeCostTexts[idx];
      if (!lvlText || !costText) return;

      lvlText.text = lvl >= 4 ? 'MAX' : `Lvl ${lvl}`;

      if (lvl >= 4) {
        costText.text = 'MAX';
      } else {
        const cost = UPGRADE_COSTS[lvl];
        costText.text = `▲ ${cost}`;
      }
    });
  }

  function summonHero() {
    if (gameState !== 'BATTLE' || isGameOver) return;
    if (mana < summonCost) {
      spawnFloatingText('Need Soul Aether!', 480, 440, '#ef4444');
      return;
    }

    const emptyIndices = grid.map((v, i) => (v === null ? i : null)).filter((v): v is number => v !== null);
    if (emptyIndices.length === 0) {
      spawnFloatingText('Battlement Full!', 480, 440, '#ef4444');
      return;
    }

    mana -= summonCost;
    summonCost += 10;
    if (summonBtn && summonBtn.children[1]) {
      (summonBtn.children[1] as Text).text = `Summon (${summonCost}) [Space]`;
    }
    sound.playKeypress();

    const equipped = getEquippedHeroDeck();
    const randSlot = emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
    const randType = equipped[Math.floor(Math.random() * equipped.length)];

    grid[randSlot] = {
      type: randType,
      tier: 1,
      attacksRemainingForAbility: 10,
      abilityUses: 0,
      isOverheated: false,
      overheatCooldown: 0,
      aimAngle: -Math.PI / 4,
      attackProgress: 0
    };

    updateTileVisual(randSlot);
  }

  function getTargetEnemy(): Enemy | null {
    if (enemies.length === 0) return null;
    const mode = TARGET_MODES[currentTargetModeIndex];

    if (mode === 'FIRST') {
      return enemies.reduce((prev, curr) => (curr.distanceProgress > prev.distanceProgress ? curr : prev));
    }
    if (mode === 'LAST') {
      return enemies.reduce((prev, curr) => (curr.distanceProgress < prev.distanceProgress ? curr : prev));
    }
    if (mode === 'STRONGEST') {
      return enemies.reduce((prev, curr) => (curr.hp > prev.hp ? curr : prev));
    }
    if (mode === 'WEAKEST') {
      return enemies.reduce((prev, curr) => (curr.hp < prev.hp ? curr : prev));
    }
    return enemies[0];
  }

  function deployLaneHazard(hero: GridHero, target: Enemy | null) {
    if (hazards.length >= 8) {
      const old = hazards.shift();
      if (old) {
        hazardLayer.removeChild(old.container);
        old.container.destroy({ children: true });
      }
    }

    const hazardX = target ? target.x : WAYPOINTS[1].x;
    const hazardY = target ? target.y : WAYPOINTS[1].y;

    const hazardGfx = new Graphics();
    const hazardContainer = new Container();
    hazardContainer.position.set(hazardX, hazardY);
    hazardContainer.addChild(hazardGfx);
    hazardLayer.addChild(hazardContainer);

    const hazardType = hero.type.id;
    const heroLevel = hero.type.level;
    let duration = 5.0;
    let radius = 24;
    let hp = 100;

    if (hazardType === 'archer') {
      radius = 24 + heroLevel * 4;
      duration = 5.0 + heroLevel * 1.0;
      hazardGfx.circle(0, 0, radius);
      hazardGfx.fill({ color: 0x15803d, alpha: 0.35 });
      hazardGfx.stroke({ width: 2, color: 0x86efac });
    } else if (hazardType === 'knight') {
      radius = 20;
      duration = 6.0 + heroLevel * 1.5;
      hp = (100 + heroLevel * 75) * hero.tier;
      hazardGfx.rect(-16, -16, 32, 32);
      hazardGfx.fill(0x78350f);
      hazardGfx.stroke({ width: 3, color: 0xfde047 });
    } else if (hazardType === 'horseman') {
      radius = 26 + heroLevel * 6;
      duration = 4.5 + heroLevel * 1.0;
      hazardGfx.circle(0, 0, radius);
      hazardGfx.fill({ color: 0xb45309, alpha: 0.45 });
      hazardGfx.stroke({ width: 2, color: 0xfde047 });
    } else if (hazardType === 'mage') {
      radius = 24 + heroLevel * 5;
      duration = 4.5;
      hazardGfx.circle(0, 0, radius);
      hazardGfx.fill({ color: 0x0284c7, alpha: 0.45 });
      hazardGfx.stroke({ width: 3, color: 0xe0f2fe });
    } else if (hazardType === 'trebuchet') {
      radius = 34 + heroLevel * 6;
      duration = 4.0;
      hazardGfx.circle(0, 0, radius);
      hazardGfx.fill({ color: 0x6b21a8, alpha: 0.5 });
      hazardGfx.stroke({ width: 3, color: 0xd8b4fe });

      const burstDmg = (50 + heroLevel * 25) * hero.tier;
      enemies.forEach((e) => {
        if (Math.hypot(e.x - hazardX, e.y - hazardY) <= radius + 15) {
          e.hp -= burstDmg;
          spawnFloatingText(`-${burstDmg}`, e.x, e.y - 15, '#c084fc');
        }
      });
      triggerScreenShake(6, 0.15);
    }

    hazards.push({
      id: Math.random().toString(),
      type: hazardType,
      x: hazardX,
      y: hazardY,
      radius, duration, hp,
      color: hero.type.pedestalColor,
      level: heroLevel,
      container: hazardContainer,
      gfx: hazardGfx
    });
  }

  function triggerHeroAttack(slotIndex: number) {
    if (gameState !== 'BATTLE' || isGameOver) return;
    const hero = grid[slotIndex];
    if (!hero) return;

    if (hero.isOverheated) {
      sound.playKeypress();
      spawnFloatingText('Resting!', tileContainers[slotIndex].x + cellW / 2, tileContainers[slotIndex].y + 15, '#94a3b8');
      return;
    }

    const tilePos = tileContainers[slotIndex].position;
    const heroLevel = hero.type.level;
    const dmgMultiplier = 1 + (heroLevel - 1) * 0.45;
    const finalDamage = Math.round(hero.type.baseDamage * hero.tier * dmgMultiplier);

    const startX = tilePos.x + cellW / 2;
    const startY = tilePos.y + cellH / 2;

    const target = getTargetEnemy();
    const targetX = target ? target.x : WAYPOINTS[1].x;
    const targetY = target ? target.y : WAYPOINTS[1].y;
    const aimAngle = Math.atan2(targetY - startY, targetX - startX);

    hero.aimAngle = aimAngle;
    hero.attackProgress = 1.0;

    sound.playKeypress();
    if (hero.type.id === 'archer') sound.playArrowShoot();
    else if (hero.type.id === 'knight' || hero.type.id === 'horseman') sound.playSlash();
    else if (hero.type.id === 'mage') sound.playMagicBlast();
    else sound.playImpact();

    const projTex = GameTextures[hero.type.projTextureKey] || Texture.WHITE;
    const projSprite = new Sprite(projTex);
    projSprite.anchor.set(0.5);
    projSprite.width = hero.type.projRadius * 2;
    projSprite.height = hero.type.projRadius * 2;
    projSprite.position.set(startX, startY);
    projSprite.rotation = aimAngle;
    projectileLayer.addChild(projSprite);

    projectiles.push({
      x: startX,
      y: startY,
      heroId: hero.type.id,
      tier: hero.tier,
      targetEnemy: target,
      targetX, targetY,
      damage: finalDamage,
      speed: hero.type.projSpeed,
      color: hero.type.pedestalColor,
      rotation: aimAngle,
      spinSpeed: hero.type.id === 'knight' ? 14 : hero.type.id === 'trebuchet' ? 5 : 0,
      isCleave: hero.type.id === 'knight' && heroLevel >= 3,
      isSplashFreeze: hero.type.id === 'mage' && heroLevel >= 3,
      sprite: projSprite
    });

    hero.attacksRemainingForAbility--;
    if (hero.attacksRemainingForAbility <= 0) {
      deployLaneHazard(hero, target);
      hero.abilityUses++;
      hero.attacksRemainingForAbility = 10;

      if (hero.abilityUses >= 3) {
        hero.isOverheated = true;
        hero.overheatCooldown = Math.max(1.8, 4.0 - (heroLevel - 1) * 0.9);
        spawnFloatingText('REST!', tileContainers[slotIndex].x + cellW / 2, tileContainers[slotIndex].y + 10, '#ef4444');
      }
    }

    updateTileVisual(slotIndex);
  }

  // Keyboard Routing
  window.addEventListener(
    'keydown',
    (e: KeyboardEvent) => {
      if (e.repeat) return;

      if (gameState !== 'BATTLE') {
        if (e.code === 'Space' || e.code === 'Enter' || e.key === ' ' || e.key === 'Enter') {
          sound.playWarHorn();
          startMatch();
        }
        return;
      }

      if (e.code === 'Tab' || e.key === 'Tab') {
        e.preventDefault();
        cycleTargetMode();
        return;
      }

      const numMap: Record<string, number> = {
        Digit1: 0, Digit2: 1, Digit3: 2, Digit4: 3, Digit5: 4,
        '1': 0, '2': 1, '3': 2, '4': 3, '5': 4
      };
      if (numMap[e.code] !== undefined || numMap[e.key] !== undefined) {
        const idx = numMap[e.code] !== undefined ? numMap[e.code] : numMap[e.key];
        e.preventDefault();
        upgradeHeroCard(idx);
        return;
      }

      if (e.code === 'Space' || e.key === ' ' || e.key === 'Spacebar') {
        e.preventDefault();
        summonHero();
        return;
      }

      const slotIndex = KEY_MAP[e.code] !== undefined ? KEY_MAP[e.code] : KEY_MAP[e.key];
      if (slotIndex !== undefined) {
        e.preventDefault();
        triggerHeroAttack(slotIndex);
      }
    },
    { capture: true, passive: false }
  );

  function restartMatch() {
    modalLayer.removeChildren();
    screenShakeTimer = 0;
    screenShakeMagnitude = 0;
    resizeGameView();

    enemies.forEach((e) => e.container.destroy({ children: true }));
    projectiles.forEach((p) => p.sprite.destroy());
    hazards.forEach((h) => h.container.destroy({ children: true }));
    floatingTexts.forEach((f) => f.text.destroy());
    particles.forEach((p) => p.gfx.destroy());

    enemies = [];
    projectiles = [];
    hazards = [];
    floatingTexts = [];
    particles = [];

    for (let i = 0; i < 15; i++) {
      grid[i] = null;
      updateTileVisual(i);
    }

    castleHp = 100;
    updateCastleHpVisual();
    mana = 160;
    summonCost = 40;
    if (summonBtn && summonBtn.children[1]) {
      (summonBtn.children[1] as Text).text = `Summon (${summonCost}) [Space]`;
    }
    currentWave = 1;
    maxWavesForLevel = 3 + Math.floor(currentCampaignLevel / 4);
    waveEnemiesSpawned = 0;
    waveEnemiesTotal = 8 + currentCampaignLevel * 2;
    bossSpawnedThisWave = false;
    isGameOver = false;
    isVictory = false;

    goldBattleText.text = `Ducats: ${saveData.sovereignDucats}`;
    levelWaveText.text = `Stage ${currentCampaignLevel} - Wave ${currentWave}/${maxWavesForLevel}`;
    refreshBottomDeckTray();
  }

  function startNextWave() {
    saveData.antimatter = Math.max(0, saveData.antimatter) + 1;
    writeSaveData(saveData);
    spawnFloatingText('+1 ANTIMATTER!', 480, 200, '#c084fc');

    currentWave++;
    waveEnemiesSpawned = 0;
    bossSpawnedThisWave = false;
    waveEnemiesTotal = 8 + currentWave * 3 + currentCampaignLevel * 2;
    waveSpawnInterval = Math.max(0.65, 1.5 - currentWave * 0.08);
    levelWaveText.text = `Stage ${currentCampaignLevel} - Wave ${currentWave}/${maxWavesForLevel}`;
  }

  function spawnEnemy(forcedType?: EnemyId) {
    const enemyContainer = new Container();

    let type: EnemyId = forcedType || 'grunt';
    if (!forcedType) {
      const roll = Math.random();
      if (roll < 0.3) type = 'scout';
      else if (roll < 0.55) type = 'tank';
      else type = 'grunt';
    }

    const lvlScalar = 1 + (currentCampaignLevel - 1) * 0.18 + (currentWave - 1) * 0.12;

    let baseHp = 65;
    let baseSpeed = 75;
    let spriteSize = 48; // Scaled up
    let texKey = 'creepGrunt';

    if (type === 'scout') {
      baseHp = 35;
      baseSpeed = 110;
      spriteSize = 40;
      texKey = 'creepScout';
    } else if (type === 'tank') {
      baseHp = 150;
      baseSpeed = 46;
      spriteSize = 56;
      texKey = 'creepTank';
    } else if (type === 'boss') {
      baseHp = 550;
      baseSpeed = 38;
      spriteSize = 72;
      texKey = 'creepBoss';
    }

    const maxHp = Math.round(baseHp * lvlScalar);

    const enemySprite = new Sprite(GameTextures[texKey] || Texture.WHITE);
    enemySprite.anchor.set(0.5);
    enemySprite.width = spriteSize;
    enemySprite.height = spriteSize;
    enemyContainer.addChild(enemySprite);

    const hpBar = new Graphics();
    hpBar.rect(-spriteSize / 2, -spriteSize / 2 - 8, spriteSize, 4);
    hpBar.fill(0x16a34a);
    enemyContainer.addChild(hpBar);

    if (type === 'boss') {
      const bossTag = new Text({
        text: 'WARLORD',
        style: new TextStyle({ fontFamily: 'Lilita One', fill: '#facc15', fontSize: 10 })
      });
      bossTag.anchor.set(0.5);
      bossTag.position.set(0, -spriteSize / 2 - 16);
      enemyContainer.addChild(bossTag);
    }

    enemyContainer.position.set(WAYPOINTS[0].x, WAYPOINTS[0].y);
    enemyLayer.addChild(enemyContainer);

    enemies.push({
      id: nextEnemyId++,
      type,
      x: WAYPOINTS[0].x,
      y: WAYPOINTS[0].y,
      hp: maxHp,
      maxHp,
      speed: baseSpeed,
      currentSpeed: baseSpeed,
      distanceProgress: 0,
      waypointIndex: 1,
      isBoss: type === 'boss',
      freezeTimer: 0,
      hitFlinchTimer: 0,
      flinchX: 0,
      flinchY: 0,
      walkCycleTimer: Math.random() * 10,
      container: enemyContainer,
      sprite: enemySprite,
      hpBar: hpBar
    });
  }

  function showDefeatModal() {
    isGameOver = true;
    screenShakeTimer = 0;
    screenShakeMagnitude = 0;
    resizeGameView();

    const overlay = new Graphics();
    overlay.rect(0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);
    overlay.fill({ color: 0x000000, alpha: 0.88 });
    modalLayer.addChild(overlay);

    const defeatText = new Text({
      text: 'THE KEEP HAS FALLEN\nYour Treasury was pillaged!',
      style: new TextStyle({ fontFamily: 'Cinzel Decorative', fill: '#dc2626', fontSize: 24, fontWeight: 'bold', align: 'center' })
    });
    defeatText.anchor.set(0.5);
    defeatText.position.set(480, 230);
    modalLayer.addChild(defeatText);

    const restartBtn = createUiButton(
      GameTextures.btnBlue,
      GameTextures.btnBluePressed,
      180, 44,
      'RETRY SIEGE',
      new TextStyle({ fontFamily: 'Lilita One', fill: '#ffffff', fontSize: 13 }),
      () => restartMatch()
    );
    restartBtn.position.set(380, 350);
    modalLayer.addChild(restartBtn);

    const menuBtn = createUiButton(
      GameTextures.btnBeige,
      GameTextures.btnBeigePressed,
      160, 44,
      'WAR ROOM',
      new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 13 }),
      () => returnToMenu()
    );
    menuBtn.position.set(580, 350);
    modalLayer.addChild(menuBtn);
  }

  function showVictoryModal() {
    isVictory = true;

    // Reset camera shake immediately so screen is never shifted
    screenShakeTimer = 0;
    screenShakeMagnitude = 0;
    resizeGameView();

    // Clean up remaining projectiles & hazards to prevent stray graphics
    projectiles.forEach(p => p.sprite.destroy());
    projectiles = [];
    hazards.forEach(h => h.container.destroy({ children: true }));
    hazards = [];

    saveData.antimatter = Math.max(0, saveData.antimatter) + 2;
    const goldBounty = currentCampaignLevel * 80;
    saveData.sovereignDucats += goldBounty;

    if (currentCampaignLevel === saveData.unlockedLevel && currentCampaignLevel < TOTAL_CAMPAIGN_LEVELS) {
      saveData.unlockedLevel++;
    }
    writeSaveData(saveData);

    const overlay = new Graphics();
    overlay.rect(0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);
    overlay.fill({ color: 0x000000, alpha: 0.88 });
    modalLayer.addChild(overlay);

    const vicText = new Text({
      text: `REALM DEFENDED!\nStage ${currentCampaignLevel} Victorious`,
      style: new TextStyle({ fontFamily: 'Cinzel Decorative', fill: '#16a34a', fontSize: 24, fontWeight: 'bold', align: 'center' })
    });
    vicText.anchor.set(0.5);
    vicText.position.set(480, 200);
    modalLayer.addChild(vicText);

    const rewardText = new Text({
      text: `+${goldBounty} Sovereign Ducats  |  +2 Bonus Antimatter Crystals`,
      style: new TextStyle({ fontFamily: 'Lilita One', fill: '#facc15', fontSize: 15 })
    });
    rewardText.anchor.set(0.5);
    rewardText.position.set(480, 275);
    modalLayer.addChild(rewardText);

    const nextBtn = createUiButton(
      GameTextures.btnBlue,
      GameTextures.btnBluePressed,
      180, 44,
      'ADVANCE MARCH',
      new TextStyle({ fontFamily: 'Lilita One', fill: '#ffffff', fontSize: 13 }),
      () => {
        if (currentCampaignLevel < TOTAL_CAMPAIGN_LEVELS) currentCampaignLevel++;
        restartMatch();
      }
    );
    nextBtn.position.set(380, 350);
    modalLayer.addChild(nextBtn);

    const menuBtn = createUiButton(
      GameTextures.btnBeige,
      GameTextures.btnBeigePressed,
      160, 44,
      'WAR ROOM',
      new TextStyle({ fontFamily: 'Lilita One', fill: '#78350f', fontSize: 13 }),
      () => returnToMenu()
    );
    menuBtn.position.set(580, 350);
    modalLayer.addChild(menuBtn);
  }

  // --- CONTINUOUS TICK LOOP ---
  let lastTime = performance.now();

  app.ticker.add(() => {
    const now = performance.now();
    const dt = (now - lastTime) / 1000;
    lastTime = now;

    if (gameState === 'MENU') return;
    if (isGameOver || isVictory) return;

    if (screenShakeTimer > 0) {
      screenShakeTimer -= dt;
      app.stage.position.set(
        (window.innerWidth - VIRTUAL_WIDTH * app.stage.scale.x) / 2 + (Math.random() - 0.5) * screenShakeMagnitude * 2,
        (window.innerHeight - VIRTUAL_HEIGHT * app.stage.scale.y) / 2 + (Math.random() - 0.5) * screenShakeMagnitude * 2
      );
      if (screenShakeTimer <= 0) resizeGameView();
    }

    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.gfx.position.set(p.x, p.y);
      p.gfx.alpha = Math.max(0, p.life / p.maxLife);
      if (p.life <= 0) {
        p.gfx.parent?.removeChild(p.gfx);
        p.gfx.destroy();
        particles.splice(i, 1);
      }
    }

    mana += 3.8 * dt;
    manaText.text = `Aether: ${Math.floor(mana)}`;
    updateUpgradeCardsUI();

    for (let f = floatingTexts.length - 1; f >= 0; f--) {
      const ft = floatingTexts[f];
      ft.life -= dt;
      ft.y += ft.vy * dt;
      ft.text.position.set(ft.x, ft.y);
      ft.text.alpha = Math.max(0, ft.life / ft.maxLife);
      if (ft.life <= 0) {
        floatLayer.removeChild(ft.text);
        ft.text.destroy();
        floatingTexts.splice(f, 1);
      }
    }

    // Hero Animations: Characters stay 100% upright, flipping wrapper scale.x (not sprite scale) to preserve size
    for (let i = 0; i < 15; i++) {
      const hero = grid[i];
      if (hero) {
        if (hero.isOverheated) {
          hero.overheatCooldown -= dt;
          if (hero.overheatCooldown <= 0) {
            hero.isOverheated = false;
            hero.abilityUses = 0;
            updateTileVisual(i);
          } else {
            tileRestTexts[i].text = `REST\n${hero.overheatCooldown.toFixed(1)}s`;
          }
        }

        const wrapper = tileHeroWrappers[i];
        const sprite = tileHeroSprites[i];

        // Horizontal flip via wrapper without resetting sprite.width / sprite.height
        const facingLeft = Math.cos(hero.aimAngle) < 0;
        wrapper.scale.set(facingLeft ? -1 : 1, 1);

        // Keep sprite size fixed
        sprite.width = HERO_SIZE;
        sprite.height = HERO_SIZE;

        if (hero.attackProgress > 0) {
          hero.attackProgress = Math.max(0, hero.attackProgress - dt * 3.8);
          const t = 1.0 - hero.attackProgress;
          const lunge = t < 0.5 ? Math.sin(t * Math.PI) * 8 : Math.sin(t * Math.PI) * 4;
          wrapper.position.set(
            cellW / 2 + Math.cos(hero.aimAngle) * lunge,
            cellH / 2 + Math.sin(hero.aimAngle) * lunge
          );
        } else {
          const idleBob = Math.sin(now * 0.003 + i) * 1.5;
          wrapper.position.set(cellW / 2, cellH / 2 + idleBob);
        }
      }
    }

    // Wave Spawner
    if (waveEnemiesSpawned < waveEnemiesTotal) {
      spawnTimer += dt;
      if (spawnTimer >= waveSpawnInterval) {
        spawnTimer = 0;
        spawnEnemy();
        waveEnemiesSpawned++;
      }
    } else if (!bossSpawnedThisWave) {
      spawnEnemy('boss');
      bossSpawnedThisWave = true;
    } else if (enemies.length === 0) {
      waveIntermissionTimer += dt;
      if (waveIntermissionTimer >= 1.5) {
        waveIntermissionTimer = 0;
        if (currentWave >= maxWavesForLevel) {
          showVictoryModal();
        } else {
          startNextWave();
        }
      }
    }

    // Hazards
    for (let hIdx = hazards.length - 1; hIdx >= 0; hIdx--) {
      const h = hazards[hIdx];
      h.duration -= dt;

      if (h.duration <= 0 || (h.hp !== undefined && h.hp <= 0)) {
        hazardLayer.removeChild(h.container);
        h.container.destroy({ children: true });
        hazards.splice(hIdx, 1);
        continue;
      }

      for (const e of enemies) {
        const dist = Math.hypot(e.x - h.x, e.y - h.y);
        if (dist <= h.radius) {
          if (h.type === 'archer') {
            const slowFactor = h.level >= 2 ? 0.35 : 0.5;
            e.currentSpeed = e.speed * slowFactor;
            e.hp -= (10 + h.level * 4) * dt;
          } else if (h.type === 'horseman') {
            e.hp -= (24 + h.level * 10) * dt;
          } else if (h.type === 'mage') {
            e.freezeTimer = 1.6 + h.level * 0.5;
          } else if (h.type === 'knight' && h.hp !== undefined) {
            e.currentSpeed = 0;
            h.hp -= 35 * dt;
          }
        }
      }
    }

    // Move Creeps
    for (let i = enemies.length - 1; i >= 0; i--) {
      const e = enemies[i];

      if (e.freezeTimer > 0) {
        e.freezeTimer -= dt;
        continue;
      }

      const targetWp = WAYPOINTS[e.waypointIndex];
      const dx = targetWp.x - e.x;
      const dy = targetWp.y - e.y;
      const dist = Math.hypot(dx, dy);

      if (dist < 6) {
        e.waypointIndex++;
        if (e.waypointIndex >= WAYPOINTS.length) {
          castleHp = Math.max(0, castleHp - (e.isBoss ? 35 : 10));
          updateCastleHpVisual();
          triggerScreenShake(8, 0.25);
          sound.playImpact();
          enemyLayer.removeChild(e.container);
          e.container.destroy({ children: true });
          enemies.splice(i, 1);

          if (castleHp <= 0) showDefeatModal();
          continue;
        }
      } else {
        const step = e.currentSpeed * dt;
        e.x += (dx / dist) * step;
        e.y += (dy / dist) * step;
        e.distanceProgress += step;
        e.sprite.rotation = Math.atan2(dy, dx) - Math.PI / 2;
      }

      e.currentSpeed = e.speed;

      if (e.hitFlinchTimer > 0) {
        e.hitFlinchTimer -= dt;
        const flinchRatio = e.hitFlinchTimer / 0.12;
        e.container.position.set(e.x + e.flinchX * flinchRatio, e.y + e.flinchY * flinchRatio);
        e.sprite.tint = 0xffe4e6;
      } else {
        e.container.position.set(e.x, e.y);
        e.sprite.tint = 0xffffff;
      }

      const hpPercent = Math.max(0, e.hp / e.maxHp);
      const barW = e.sprite.width;
      e.hpBar.clear();
      e.hpBar.rect(-barW / 2, -barW / 2 - 8, barW * hpPercent, 4);
      e.hpBar.fill(hpPercent > 0.4 ? 0x16a34a : 0xdc2626);
    }

    // Continuous Hit Collision (with NaN protections)
    for (let i = projectiles.length - 1; i >= 0; i--) {
      const p = projectiles[i];
      let target = (p.targetEnemy && enemies.includes(p.targetEnemy)) ? p.targetEnemy : null;

      if (!target && enemies.length > 0) {
        let closestDist = Infinity;
        for (const e of enemies) {
          const d = Math.hypot(e.x - p.x, e.y - p.y);
          if (d < closestDist) {
            closestDist = d;
            target = e;
          }
        }
      }

      const destX = target ? target.x : p.targetX;
      const destY = target ? target.y : p.targetY;
      const dx = destX - p.x;
      const dy = destY - p.y;
      const dist = Math.hypot(dx, dy);
      const step = p.speed * 60 * dt;

      let hitEnemy: Enemy | null = null;
      for (const e of enemies) {
        const hitRadius = (e.isBoss ? 32 : e.type === 'tank' ? 26 : 22) + p.tier * 2;
        if (Math.hypot(e.x - p.x, e.y - p.y) <= hitRadius) {
          hitEnemy = e;
          break;
        }
      }

      if (hitEnemy || dist <= step || dist < 12) {
        const victim = hitEnemy || target;
        if (victim) {
          victim.hp -= p.damage;
          victim.hitFlinchTimer = 0.12;
          const vdx = victim.x - p.x;
          const vdy = victim.y - p.y;
          const vdist = Math.hypot(vdx, vdy) || 1;
          victim.flinchX = (vdx / vdist) * 5;
          victim.flinchY = (vdy / vdist) * 5;

          sound.playImpact();
          spawnImpactParticles(projectileLayer, victim.x, victim.y, p.color, 8);
          spawnFloatingText(`-${p.damage}`, victim.x, victim.y - 14, '#fef08a');

          if (p.heroId === 'trebuchet') {
            triggerScreenShake(6, 0.18);
          }

          if (p.isCleave) {
            enemies.forEach(other => {
              if (other !== victim && Math.hypot(other.x - victim.x, other.y - victim.y) <= 50) {
                other.hp -= Math.round(p.damage * 0.6);
                other.hitFlinchTimer = 0.1;
                spawnFloatingText(`-${Math.round(p.damage * 0.6)}`, other.x, other.y - 14, '#ef4444');
              }
            });
          }

          if (p.isSplashFreeze) {
            enemies.forEach(other => {
              if (Math.hypot(other.x - victim.x, other.y - victim.y) <= 45) {
                other.freezeTimer = 1.8;
              }
            });
          }

          if (victim.hp <= 0) {
            const rewardAether = victim.isBoss ? 75 : 18;
            mana += rewardAether;
            saveData.sovereignDucats += victim.isBoss ? 25 : 4;
            writeSaveData(saveData);
            spawnFloatingText(`+${rewardAether} Aether`, victim.x, victim.y - 26, '#38bdf8');

            const eIdx = enemies.indexOf(victim);
            if (eIdx !== -1) {
              enemyLayer.removeChild(victim.container);
              victim.container.destroy({ children: true });
              enemies.splice(eIdx, 1);
            }
          }
        } else {
          spawnImpactParticles(projectileLayer, p.x, p.y, p.color, 4);
        }

        projectileLayer.removeChild(p.sprite);
        p.sprite.destroy();
        projectiles.splice(i, 1);
      } else {
        if (dist > 0.001) {
          p.x += (dx / dist) * step;
          p.y += (dy / dist) * step;
          p.sprite.position.set(p.x, p.y);

          if (p.spinSpeed) {
            p.rotation += p.spinSpeed * dt;
            p.sprite.rotation = p.rotation;
          } else {
            p.rotation = Math.atan2(dy, dx);
            p.sprite.rotation = p.rotation;
          }
        }
      }
    }
  });

  battleRoot.visible = false;
  menuRoot.visible = true;
  renderStartMenu();
}

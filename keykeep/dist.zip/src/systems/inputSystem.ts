import type { Container } from 'pixi.js';
import { KEY_MAP } from '../constants';

export interface InputHandlers {
  onHeroKey(index: number): void;
  onTab(): void;
  onSummon(): void;
}

export function installInputSystem(target: Window, _stage: Container, handlers: InputHandlers): () => void {
  const onKeyDown = (event: KeyboardEvent): void => {
    if (event.code === 'Tab') { event.preventDefault(); handlers.onTab(); return; }
    if (event.code === 'Space') { event.preventDefault(); handlers.onSummon(); return; }
    const index = KEY_MAP[event.code] ?? KEY_MAP[event.key];
    if (index !== undefined) handlers.onHeroKey(index);
  };
  target.addEventListener('keydown', onKeyDown);
  return () => target.removeEventListener('keydown', onKeyDown);
}

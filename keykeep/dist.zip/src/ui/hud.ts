import { Container, Graphics, Text } from 'pixi.js';

export interface HudRefs {
  root: Container;
  manaText: Text;
  castleBar: Graphics;
}

export function createHud(): HudRefs {
  const root = new Container();
  const manaText = new Text({ text: 'MANA 160', style: { fill: 0xffffff, fontSize: 14 } });
  const castleBar = new Graphics();
  root.addChild(manaText, castleBar);
  return { root, manaText, castleBar };
}

export function updateHud(refs: HudRefs, mana: number, castleHp: number): void {
  refs.manaText.text = `MANA ${Math.round(mana)}`;
  refs.castleBar.clear().rect(0, 0, Math.max(0, castleHp) * 1.2, 8).fill(0xdc2626);
}

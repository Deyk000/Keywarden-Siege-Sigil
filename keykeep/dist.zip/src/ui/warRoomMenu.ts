import { Container, Text } from 'pixi.js';
import type { MenuTab } from '../types';

export function createWarRoomMenu(): Container {
  const root = new Container();
  root.addChild(new Text({ text: 'WAR ROOM', style: { fill: 0xffffff, fontSize: 24 } }));
  return root;
}

export function setMenuTab(root: Container, tab: MenuTab): void {
  root.label = `war-room-${tab.toLowerCase()}`;
}

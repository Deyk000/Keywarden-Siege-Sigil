import { Container, NineSliceSprite, Text, type TextStyle, Texture } from 'pixi.js';
import { sound } from '../audio';

export function createUiButton(
  normalTexture: Texture, pressedTexture: Texture, width: number, height: number,
  label: string, textStyle: TextStyle, onClick: () => void
): Container {
  const container = new Container();
  container.eventMode = 'static';
  container.cursor = 'pointer';
  const slice = new NineSliceSprite({
    texture: normalTexture, leftWidth: 16, topHeight: 16, rightWidth: 16, bottomHeight: 16, width, height
  });
  container.addChild(slice);
  const text = new Text({ text: label, style: textStyle });
  text.anchor.set(0.5);
  text.position.set(width / 2, height / 2);
  container.addChild(text);
  container.on('pointerdown', () => { slice.texture = pressedTexture; sound.playKeypress(); onClick(); });
  container.on('pointerup', () => { slice.texture = normalTexture; });
  container.on('pointerupoutside', () => { slice.texture = normalTexture; });
  return container;
}

export function createPanel(
  texture: Texture, x: number, y: number, width: number, height: number, inset = 16
): NineSliceSprite {
  const panel = new NineSliceSprite({
    texture, leftWidth: inset, topHeight: inset, rightWidth: inset, bottomHeight: inset, width, height
  });
  panel.position.set(x, y);
  return panel;
}

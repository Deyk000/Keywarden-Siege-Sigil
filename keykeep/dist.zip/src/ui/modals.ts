import { Container, Text } from 'pixi.js';

export function createModal(title: string, message: string): Container {
  const modal = new Container();
  modal.addChild(
    new Text({ text: title, style: { fill: 0xffffff, fontSize: 22 } }),
    new Text({ text: message, style: { fill: 0xd1d5db, fontSize: 14 } })
  );
  return modal;
}
